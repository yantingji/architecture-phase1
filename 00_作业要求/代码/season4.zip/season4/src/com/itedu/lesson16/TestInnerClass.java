package com.itedu.lesson16;

public class TestInnerClass {

	public static void main(String[] args) {
		OuterClass.InnerClass innerClass = new OuterClass().new InnerClass();
		innerClass.test();
	}

}
