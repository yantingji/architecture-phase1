package com.itedu.lesson16;

public interface Flyable {
	void fly();
}
