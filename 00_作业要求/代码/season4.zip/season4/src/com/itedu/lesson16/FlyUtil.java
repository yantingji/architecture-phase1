package com.itedu.lesson16;

public class FlyUtil {
	void test(Flyable flyable){
		flyable.fly();
	}
}
