package com.itedu.lesson16;

public class OuterClass3 {
	class InnerClass3 extends OuterClass2.InnerClass1 {
		public InnerClass3(OuterClass2 oc2) {
			oc2.super();
		}
	}

	public static void main(String[] args) {
		OuterClass3.InnerClass3 c3 = new OuterClass3().new InnerClass3(
				new OuterClass2());
	}
}
