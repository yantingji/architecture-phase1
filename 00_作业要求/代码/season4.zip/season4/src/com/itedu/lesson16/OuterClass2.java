package com.itedu.lesson16;

public class OuterClass2 {
	class InnerClass1 {

	}

	class InnerClass2 extends InnerClass1 {

	}
	
	class InnerClass3 extends OuterClass2{
		
	}
	
	
}
