package com.itedu.lesson16;

public class OuterClass {

	static int num = 10;

	public static void test() {
		class InnerClass {
			public void test() {
				System.out.println(num);
			}
		}
	}
	
	class InnerClass{
		void test(){
			
		}
	}
}
