package com.itedu.lesson16;
public class OuterClass4 {
	private static int age=20;
	
	static class InnerClass{
		public void test(){
			System.out.println(age);
		}
	}
	
	public static void main(String[] args) {
		OuterClass4.InnerClass innerClass=new OuterClass4.InnerClass();
		innerClass.test();
	}
}
