package com.itedu.lesson16;

public class TestInnerClass2 {

	public static void main(String[] args) {
		FlyUtil util = new FlyUtil();
		util.test(new Flyable() {

			@Override
			public void fly() {
				System.out.println("flying");

			}
		});
	}

}
