package com.itedu.lesson11;

/**
 * 实体�?
 * 
 * @author tanlan
 *
 */
public class Dog {
	private int health;
	private String name;
	private String myBirhdate;

	public void setHealth(int health) {
		if (health < 0) {
			this.health = 100;
			return;
		}
		this.health = health;
	}

	public int getHealth() {
		return this.health;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMyBirhdate() {
		return myBirhdate;
	}

	public void setMyBirhdate(String myBirhdate) {
		this.myBirhdate = myBirhdate;
	}

}
