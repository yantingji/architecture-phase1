package com.itedu.lesson11;

public class DogTest {

	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.setHealth(-100);
		int health=dog.getHealth();
		System.out.println(health);
		dog.setName("旺财");
		dog.setMyBirhdate("2009-10-10");
		System.out.println(dog.getName());
		System.out.println(dog.getMyBirhdate());
	}

}
