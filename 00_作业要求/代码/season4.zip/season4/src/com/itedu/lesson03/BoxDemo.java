package com.itedu.lesson03;

public class BoxDemo {

	// static Integer add(Integer num1, Integer num2) {
	// int i1 = num1.intValue();
	// int i2 = num2.intValue();
	// return new Integer(i1 + i2);
	// }

	static int add(int num1, int num2) {
		return num1 + num2;
	}

	public static void main(String[] args) {
		Integer num1 = 100;// 自动装箱
		int num2 = num1;// 自动拆箱

		Integer result = add(new Integer(100), new Integer(200));

		int r = add(100, 200);

		// Integer i = null;
		// int num3 = i;

		Integer i1 = 100, i2 = 200;
		System.out.println(i1 < i2);

		Integer i3 = 200, i4 = 200;
		System.out.println(i3 == i4);

	}

}
