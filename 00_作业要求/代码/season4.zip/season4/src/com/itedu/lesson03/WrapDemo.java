package com.itedu.lesson03;

public class WrapDemo {

	public static void main(String[] args) {
		Integer i1 = new Integer(200);
		Integer i2 = new Integer("200");

		Short s1 = new Short((short) 100);
		Short s2 = new Short("200");

		Boolean b1 = new Boolean(true);
		Boolean b2 = new Boolean("TRUe1as df");
		System.out.println(b2);

		Character c1 = new Character('a');

		System.out.println("------------------------");
		Integer i3 = Integer.valueOf(200);
		Integer i4 = Integer.valueOf("200");
		Integer i5 = Integer.valueOf("200", 8);
		System.out.println(i3 + "," + i4 + "," + i5);

		System.out.println("--------------------------");
		Integer i6 = new Integer(100);
		Integer i7 = new Integer(100);
		System.out.println(i6 == i7);
		Integer i8 = Integer.valueOf(200);
		Integer i9 = Integer.valueOf(200);
		System.out.println(i8 == i9);
	}

}
