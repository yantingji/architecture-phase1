package com.itedu.lesson05;

public abstract class Shape {
	private String name;
	
	public Shape(){
		System.out.println("Shape 构造方法");
	}
	
	static void m(){
		
	}
	
	public abstract void draw();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
