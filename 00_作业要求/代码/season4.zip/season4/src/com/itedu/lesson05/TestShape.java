package com.itedu.lesson05;

public class TestShape {
	
	public static void test(Shape shape){
		shape.draw();
	}
	

	public static void main(String[] args) {
		Shape shape=new Square();
		test(new Square());
	}

}
