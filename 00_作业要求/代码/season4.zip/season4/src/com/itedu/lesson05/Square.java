package com.itedu.lesson05;

public class Square extends Shape {

	@Override
	public void draw() {
		System.out.println("画出正方形");
	}

}
