package com.itedu.lesson05;


public abstract class AbstractClass extends Shape {


}
