package com.itedu.lesson04;

public class Dog {

}
