package com.itedu.lesson04;

public class DogTest {

	public static void main(String[] args) {
		Dog dog = new Dog();
	}

}

//class Dog{
//	
//}
