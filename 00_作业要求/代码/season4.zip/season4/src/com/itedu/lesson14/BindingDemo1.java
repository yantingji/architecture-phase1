package com.itedu.lesson14;


class Class1 {
	int num = 100;
	
	static void print(){
		System.out.println("class1 static print");
	}
	
	void print1(){
		System.out.println("class1 print1");
	}
}

class Class2 extends Class1{
	int num = 200;
	
	static void print(){
		System.out.println("class2 static print");
	}

	@Override
	void print1(){
		System.out.println("class2 print1");
	}
	
	void print2(){
		
	}
}

public class BindingDemo1 {

	public static void main(String[] args) {
		Class1 c1=new Class1();
		System.out.println(c1.num);
		c1.print();
		Class2 c2=new Class2();
		System.out.println(c2.num);
		c2.print();
		System.out.println("----------------------");
		Class1 c3=new Class2();
		System.out.println(c3.num);
		c3.print();
		c3.print1();
	}

}
