package com.itedu.lesson09;

public class TestSon {

	public static void main(String[] args) {
		new Son();
	}

}
