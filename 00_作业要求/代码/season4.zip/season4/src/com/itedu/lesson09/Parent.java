package com.itedu.lesson09;

public class Parent {
	int num1 = 10;
	{
		System.out.println(num1);
		System.out.println("Parent：实例初始化块");
	}

	static int num2 = 20;
	static {
		System.out.println(num2);
		System.out.println("Parent：静态代码块1");
	}

	public Parent() {
		System.out.println("Parent：我是构造方法");
	}
	
	static {
		System.out.println("Parent：静态代码块2");
	}
}
