package com.itedu.lesson09;

class Son extends Parent {

	int num1 = 100;
	{
		System.out.println(num1);
		System.out.println("Son：实例初始化块");
	}

	static int num2 = 200;
	static {
		System.out.println(num2);
		System.out.println("Son：静态代码块1");
	}

	public Son() {
		System.out.println("Son：我是构造方法");
	}
	
	static {
		System.out.println("Son：静态代码块2");
	}
}
