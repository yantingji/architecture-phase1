package com.itedu.lesson09;

class SingleClass  {

	int num1 = 10;
	{
		System.out.println(num1);
		System.out.println("实例初始化块");
	}

	static int num2 = 20;
	static {
		System.out.println(num2);
		System.out.println("静态代码块1");
	}

	public SingleClass() {
		System.out.println("我是构造方法");
	}
	
	static {
		System.out.println("静态代码块2");
	}
	
	public static void main(String [] args) {
		new SingleClass();
		
	}
}
