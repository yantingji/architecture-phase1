package com.itedu.lesson12;

public class MethodOverloadDemo {

	public MethodOverloadDemo() {
	}

	public MethodOverloadDemo(int num) {
	}

	void m1() {
		System.out.println("m1");
	}

	void m1(int num) {

	}

	void m1(String s) {

	}

	void m1(int num, String s) {

	}

	void m1(String s, int num) {

	}

//	 void m2(int i) {
//	 System.out.println("int");
//	 }

	// void m2(Integer i) {
	// System.out.println("Integer");
	// }

//	void m2(Object o) {
//		System.out.println("Object");
//	}

//	void m2(float f) {
//		System.out.println("float");
//	}

//	void m2(double f) {
//		System.out.println("double");
//	}
	
	void m2(int... ids){
		System.out.println("...");
	}

	public static void main(String[] args) {
		MethodOverloadDemo demo = new MethodOverloadDemo();
		//demo.m1(100);
		demo.m2(100);
		//demo.m2(new Integer(1));

	}

}
