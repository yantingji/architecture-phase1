package com.itedu.lesson06;

public class Test {

	public static void main(String[] args) {
		//Swimable.NUM=20;
		System.out.println(Swimable.NUM);
	}

}
