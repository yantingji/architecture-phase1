package com.itedu.lesson06;

public interface Flyable {

}
