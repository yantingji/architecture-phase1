package com.itedu.lesson06;

public interface Swimable2 extends Swimable {

}
