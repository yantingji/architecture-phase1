package com.itedu.lesson06;

public abstract interface Swimable {
	int NUM = 10;
	
	User user=new User();
	
	void m();
}
