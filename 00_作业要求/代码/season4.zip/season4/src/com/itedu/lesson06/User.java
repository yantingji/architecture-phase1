package com.itedu.lesson06;

public class User {

	public User(int age, String name) {
		System.out.println("User的构造方法");
		this.age = age;
		this.name = name;
	}

	public User() {

	}

	int age;
	String name;

	public static void main(String[] args) {
		User user = new User(20,"Tom");
		//user.age = 20;
		//user.name = "Tom";
		System.out.println(user.age + "," + user.name);

	}

}
