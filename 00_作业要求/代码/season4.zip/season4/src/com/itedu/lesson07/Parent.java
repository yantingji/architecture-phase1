package com.itedu.lesson07;

public class Parent {
	public Parent() {
		// TODO Auto-generated constructor stub
	}

	public Parent(int num) {
		System.out.println("Parent 构造方法");
	}

	public void m1() {
		System.out.println("m1");
	}
}
