package com.itedu.lesson07;

public class Son extends Parent {

	public Son() {
		//super();
		super(100);// 调用父类的相应构造方法
		System.out.println("Son 构造方法");
	}
	
	public Son(int num){
		super(num);
	}

	@Override
	public void m1() {
		System.out.println("Son's m1");
	}

	public void m2() {
		super.m1();
	}

	public static void main(String[] args) {
		Son son = new Son();
		// son.m2();
	}
}
