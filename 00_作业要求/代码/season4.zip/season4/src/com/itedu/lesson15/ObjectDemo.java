package com.itedu.lesson15;

class Dog {
	private String name;
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Name:" + name + ",Age:" + age;
	}
}

public class ObjectDemo {
	public static void main(String[] args) {
		Object o = new ObjectDemo();
		ObjectDemo demo = new ObjectDemo();
		Object o1 = null;

		Dog dog = new Dog();
		dog.setAge(5);
		dog.setName("旺财");
		System.out.println(dog);
		
		String result=dog+"";
		System.out.println(result);

	}
}
