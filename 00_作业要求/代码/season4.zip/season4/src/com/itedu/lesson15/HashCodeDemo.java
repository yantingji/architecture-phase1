package com.itedu.lesson15;

class Student {
	private int age;
	private String name;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		int hash = 31;
		int code = 0;

		code = age;
		code += name == null ? 0 : 1;

		hash = hash * 59 + code;
		return hash;
	}

}

public class HashCodeDemo {
	public static void main(String[] args) {
		System.out.println(new Student().hashCode());
	}
}
