package com.itedu.lesson15;

class User {
	private String name;
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj instanceof User) {
			User u = (User) obj;
			return u.getAge() == age && u.getName().equals(name);
		}
		return false;
	}
}

public class EqualsDemo {

	public static void main(String[] args) {
		int num1 = 20;
		int num2 = 21;
		System.out.println(num1 == num2);

		User user1 = new User();
		user1.setName("Tom");
		user1.setAge(21);

		User user2 = new User();
		user2.setName("Tom");
		user2.setAge(21);

		System.out.println(user1 == user2);
		System.out.println(user1.equals(user2));

	}

}
