package com.itedu.lesson19;

public class ShapeUtil {
	public static int getShapeArea(Shape shape) {
		return shape.getArea();
	}

	public static int[] getAreaAndCircle(Shape shape) {
		int[] r = new int[2];
		r[0] = shape.getArea();
		r[1] = shape.getCircle();
		return r;
	}
}
