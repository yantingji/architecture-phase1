package com.itedu.lesson19;

public abstract class Shape {
	public abstract int getArea();
	
	public abstract int getCircle();
}
