package com.itedu.lesson19;

public class TestShape {

	public static void main(String[] args) {
		Shape shape1 = new Square(20);
		System.out.println(ShapeUtil.getShapeArea(shape1));
		int[] r=ShapeUtil.getAreaAndCircle(shape1);
		System.out.println(r[0]+","+r[1]);
		Shape shape2 = new Rec(12, 23);
		System.out.println(ShapeUtil.getShapeArea(shape2));
		
		
	}

}
