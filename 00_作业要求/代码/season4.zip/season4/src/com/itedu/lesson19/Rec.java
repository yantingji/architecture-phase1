package com.itedu.lesson19;

public class Rec extends Shape {
	private int length;
	private int width;

	public Rec(int length, int width) {
		this.length = length;
		this.width = width;
	}

	@Override
	public int getArea() {
		return length * width;
	}

	@Override
	public int getCircle() {
		return (length + width) * 2;
	}

}
