package com.itedu.lesson19;

public class Square extends Shape {

	private int length;

	public Square(int length) {
		this.length = length;
	}

	@Override
	public int getArea() {
		return length * length;
	}

	@Override
	public int getCircle() {
		return length * 4;
	}

}
