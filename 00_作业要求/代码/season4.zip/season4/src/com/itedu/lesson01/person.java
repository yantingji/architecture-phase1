package com.itedu.lesson01;

public class person {
	String name;
	Integer age;
	 
	public void sleep() {
		System.out.println("Sleeping");
	}

}
