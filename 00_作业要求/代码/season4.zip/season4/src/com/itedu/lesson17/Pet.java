package com.itedu.lesson17;

public class Pet {

	private String name;
	int health;
	
	public Pet() {

	}


	void print() {

	}
}
