package com.itedu.lesson17;

public class Dog extends Pet {

}
