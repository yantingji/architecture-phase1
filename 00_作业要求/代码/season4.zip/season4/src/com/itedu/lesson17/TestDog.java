package com.itedu.lesson17;

public class TestDog {

	public static void main(String[] args) {
		Dog dog = new Dog();
		//dog.name = "hell";
		dog.health = 100;
		dog.print();
	}

}
