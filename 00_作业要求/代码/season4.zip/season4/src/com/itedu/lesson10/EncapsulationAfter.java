package com.itedu.lesson10;

public class EncapsulationAfter {
	// 封装确实可以使我们容易地修改类的内部实现，�?�无�?修改使用了该类的客户代码�?
	private int age; // ⇒�??String
	
	 //private String age;
	public int getAge() {
		return age;
		//return Integer.valueOf(age);
	}

	public void setAge(int age) {
		if(age<0||age>150) {
			System.out.println("输入有错�?");
		}
		this.age = age;
		//this.age = String.valueOf(age);
	}
}

 class EncapsulationAfter1 {
	// 封装确实可以使我们容易地修改类的内部实现，�?�无�?修改使用了该类的客户代码�?
	private int age; // ⇒�??String
	
	 //private String age;
	public int getAge() {
		return age;
		//return Integer.valueOf(age);
	}

	public void setAge(int age) {
		if(age<0||age>150) {
			System.out.println("输入有错�?");
		}
		this.age = age;
		//this.age = String.valueOf(age);
	}
}
