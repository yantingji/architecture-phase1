package com.itedu.lesson10;

public class EncapsulationBefore {
int  age;
}
