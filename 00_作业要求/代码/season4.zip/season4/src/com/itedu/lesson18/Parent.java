package com.itedu.lesson18;
class Class1 {

}

class Class2 extends Class1 {

}

public class Parent {
	int m1() {
		System.out.println("m1");
		return 1;
	}

	Class1 m2() {
		return null;
	}
	
	static void m3(){
		
	}
}
