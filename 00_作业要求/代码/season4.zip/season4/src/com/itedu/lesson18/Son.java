package com.itedu.lesson18;

public class Son extends Parent {
	@Override
	public int m1() {
		System.out.println("Son's m1");
		return 2;
	}

	@Override
	Class2 m2() {
		return null;
	}
	
	//@Override

}
