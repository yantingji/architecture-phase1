package com.itedu.lesson13;

class Class1 extends Parent {

}

public class TestCast {

	static void m(Parent p) {

	}

	public static void main(String[] args) {
		Son son = new Son();
		Parent parent = new Parent();

		Parent son2 = new Son();// 向上转型

		m(son);
		m(parent);
		m(son2);
		m(new Class1());

		// Son son3 = (Son) new Parent();// 向下转型

		// Son son4 = new Son();
		Parent p4 = new Son();
		System.out.println(p4 instanceof Son);
		if (p4 instanceof Son) {
			Son c4 = (Son) p4;
		}
		
		System.out.println(null instanceof Integer);

	}

}
