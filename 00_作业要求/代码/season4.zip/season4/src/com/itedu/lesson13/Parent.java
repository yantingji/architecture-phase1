package com.itedu.lesson13;

public class Parent {

}
