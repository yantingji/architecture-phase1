package com.itedu.lesson02;

public class MethodDemo {
	/**
	 * 计算两个整数之和
	 * 
	 * @return
	 */
	int add(int num1, int num2) {
		return num1 + num2;
	}

	/**
	 * 计算两个数组的长度之和
	 * 
	 * @return
	 */
	int getLength(int[] nums1, int[] nums2) {
		int length1 = 0, length2 = 0;
		if (nums1 != null) {
			length1 = nums1.length;
		}
		if (nums2 != null) {
			length2 = nums2.length;
		}
		return length1 + length2;
	}

	public static void main(String[] args) {
		MethodDemo demo = new MethodDemo();
		int num11 = 20;
		int num22 = 50;
		int result = demo.add(num11, num22);
		System.out.println("结果：" + result);

		int[] nums1 = { 1 }, nums2 = { 2, 3 };
		result = demo.getLength(null, nums2);
		System.out.println("长度：" + result);
	}
}
