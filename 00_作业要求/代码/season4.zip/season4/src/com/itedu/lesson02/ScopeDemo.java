package com.itedu.lesson02;

public class ScopeDemo {

	int num1;
	boolean b;
	
	//String s;

	void m1() {
		//int num1;
		String s;
		//System.out.println(s);
		// System.out.println(num1);
	}

	void m2(int num2) {
		// System.out.println(num1);
	}

	public static void main(String[] args) {
		ScopeDemo demo=new ScopeDemo();
		demo.m1();
		
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
		if (1 == 1) {
			int num;
			// System.out.println(num);
		}
		// System.out.println(num);

	}

}
