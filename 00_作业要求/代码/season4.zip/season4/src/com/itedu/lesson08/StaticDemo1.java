package com.itedu.lesson08;

public class StaticDemo1 {

	int num;

	static int num2;

	void m() {
		//static int num3 = 10;
	}

	public static void main(String[] args) {
		StaticDemo1 demo1 = new StaticDemo1();
		demo1.num = 10;
		demo1.num2 = 10;

		StaticDemo1 demo2 = new StaticDemo1();
		demo2.num = 20;
		demo2.num2 = 20;

		System.out.println(demo1.num + "," + demo2.num);
		System.out.println(demo1.num2 + "," + demo2.num2);

		StaticDemo1.num2 = 30;
		System.out.println(StaticDemo1.num2 + "," + demo1.num2 + ","
				+ demo2.num2);
	}

}
