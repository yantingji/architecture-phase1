package com.itedu.lesson08;

final class Class1 {
	void m1() {

	}
}

class Class2 {
	final int num = 10;
}

class User{
	int num;
}

public class FinalDemo {

	static{
		NUM = 20;
	}
	final static int NUM;// 不可变的常量

	void m1() {
		final int NUM1;
		NUM1 = 20;
	}

	final User user=new User();
	public static void main(String[] args) {
		FinalDemo demo = new FinalDemo();
		//demo.user=new User();
		demo.user.num=20;
		// demo.NUM=20;

		final Class2 class2 = new Class2();
		// class2.num=30;
		// class2.num=40;
	}

}
