package com.itedu.lesson08;

public class StaticDemo3 {
	static {
		System.out.print("Hello");
	}

	public static void main(String[] args) {
		//StaticDemo3 demo;//=new StaticDemo3();
		//StaticDemo3 demo1;//=new StaticDemo3();
		//StaticDemo3 demo2;//=new StaticDemo3();
	}

}
