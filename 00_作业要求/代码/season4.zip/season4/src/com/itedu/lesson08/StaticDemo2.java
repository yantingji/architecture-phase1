package com.itedu.lesson08;


public class StaticDemo2 {

	public static void m1() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		m1();

	}

}
