package com.itedu.lesson09;

import java.io.File;

public class Recursion {
	public static void main(String[] args) {
        File f=new File("C:\\temp");
        new Recursion().fileList(f);
    }
    public  void fileList(File fl){
        try{
            File[] fs=fl.listFiles();
            for(File file:fs){
                if(file.isDirectory()){
                    System.out.println(file.getName());
                     fileList(file);
                }else{
                    System.out.println(file.getName());
                }
        }
         
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
