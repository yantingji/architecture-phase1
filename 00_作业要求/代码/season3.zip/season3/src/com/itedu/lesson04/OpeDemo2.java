package com.itedu.lesson04;

public class OpeDemo2 {

	public static void main(String[] args) {
		int num1 = 10;
		float num2 = 10.0f;
		boolean b = num1 == num2;
		System.out.println(b);

		System.out.println(12 > 10);// true
		System.out.println(10 != 11);// true
		System.out.println(10 != 10);// false
		System.out.println(10 >= 10);// true
		System.out.println(10 <= 10);// true
		System.out.println(12 < 10);// false
		System.out.println("----------------------------------------------");
		boolean b2 = true && true;// true
		System.out.println(b2);
		System.out.println(true && false);// false

		System.out.println(1 == 1 && 1 > 0);// true
		System.out.println(1 != 1 && 1 > 0);// false

		System.out.println(true || false);// true
		System.out.println(false || false);// false

		System.out.println(!true);// false
		System.out.println(!(10 < 20));// false

		int num3 = 10, num4 = 10;
		boolean num5 = num3 < 8 && num4++ < 10;
		System.out.println(num4);// 10
		System.out.println(num5);// false

		boolean num7 = 10 < 20 || num4++ < 10;
		System.out.println(num4);// 10
		System.out.println(num7);// true

		System.out.println("---------------------------------");
		System.out.println(true ^ true);
		System.out.println(false ^ true);
		System.out.println(false ^ false);
		System.out.println(true ^ false);

		boolean b6 = true;
		// b6 = b6 & false;
		b6 &= false;
		System.out.println(b6);

		System.out.println("---------------------------");
		boolean b7 = 1 > 2 ? true : false;
		System.out.println(b7);

		int num = 1 > 2 ? 10 : 20;
		System.out.println(num);
	}

}
