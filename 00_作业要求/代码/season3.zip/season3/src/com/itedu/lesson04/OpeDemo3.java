package com.itedu.lesson04;

public class OpeDemo3 {

	public static void main(String[] args) {
		System.out.println(12 & 13);
		System.out.println(12 | 13);
		System.out.println(12 ^ 13);
		System.out.println(~12);

		System.out.println(12 << 2);
		System.out.println(12 >> 2);
		System.out.println(-12 >>> 2);
		
		System.out.println(Integer.toBinaryString(1073741821));
	}

}
