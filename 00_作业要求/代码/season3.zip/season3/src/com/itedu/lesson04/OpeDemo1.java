package com.itedu.lesson04;

public class OpeDemo1 {

	public static void main(String[] args) {
		int num1;
		int num2 = 0, num3 = 1, num4 = 4;

		num1 = num2;

		num1 = num2 = num3 = num4;
		System.out.println(num1);

		int num5 = 1 + 1;
		num5 = num2 + num3 + num4;

		String s = "abc" + "def";

		int result = 10 + 20;
		double result1 = 10 + 23;

		byte b1 = 1, b2 = 2;

		int r = b1 + b2;

		int num6 = -5;

		System.out.println(-6 / 2.1);
		// System.out.println(1/0);
		System.out.println(1f / 0);

		System.out.println(5 % 2.1);

		System.out.println(5 % 2); // 1
		System.out.println(-5 % 2);// -1
		System.out.println(5 % -2);// 1
		System.out.println(-5 % -2);// -1

		int num7 = 1;
		num7++;// num7自增1
		System.out.println(num7);
		num7--;// num7自减1
		System.out.println(num7);
		++num7;// num7自增1
		--num7;// num7自减1

		System.out.println(num7);

		int num8 = 1;
		int num9 = ++num8;
		System.out.println(num8);
		System.out.println(num9);
		int num10 = 10;
		num10 = num10 + 10;// 累加
		num10 += 10;

		System.out.println(1.2f - 0.4f);
		
	}

}
