package com.itedu.lesson05;

public class IfDemo3 {
	public static void main(String[] args) {
		int num = 10;
		//互斥
		if (num <= 0) {

		} else if (num <= 100) {

		} else if (num <= 1000) {

		} else {

		}
		
		//并列
		if(num<=0){
			
		}
		
		if(num>0 && num<=100){
			
		}

		if(num>100 && num<=1000){
			
		}

		if(num>1000){
			
		}
	}
}
