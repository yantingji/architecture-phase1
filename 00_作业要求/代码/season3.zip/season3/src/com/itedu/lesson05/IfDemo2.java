package com.itedu.lesson05;

public class IfDemo2 {

	public static void main(String[] args) {
		int num = 11;
		if (num % 2 == 0) {
			System.out.println("偶数");
		} else {
			System.out.println("奇数");
		}
	}

}
