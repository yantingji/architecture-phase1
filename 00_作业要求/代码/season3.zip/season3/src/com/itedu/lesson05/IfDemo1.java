package com.itedu.lesson05;

public class IfDemo1 {

	public static void main(String[] args) {
		int num = 12;
		if (num % 2 != 0) {
			System.out.println("奇数");
		}
		System.out.println("Hello");

		if (num % 2 == 0 && num > 0) {

		}
	}

}
