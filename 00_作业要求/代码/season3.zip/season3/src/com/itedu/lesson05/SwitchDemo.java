package com.itedu.lesson05;

import java.util.ArrayList;
import java.util.List;

public class SwitchDemo {

	public static void main(String[] args) {
		// System.out.print("请输入一个整�?");
		// Scanner scanner = new Scanner(System.in);
		// int num = scanner.nextInt();
		byte b = 2;
		byte b2=2;
		if(b>1){
			
		}else{
			
		}
		
		switch (b) {
		case 1:
			System.out.println("�?");
			break;
		case 127:
			System.out.println("�?");
			break;
			
		default:
			System.out.println("数字不合法！");
			break;
		case 3:
			System.out.println("�?");
			break;
		case 4:
			System.out.println("�?");
			break;
		case 5:
			System.out.println("�?");
			break;
		// default:
		// System.out.println("数字不合法！");
		// break;
		}
	}

}
