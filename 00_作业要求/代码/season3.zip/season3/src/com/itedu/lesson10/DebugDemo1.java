package com.itedu.lesson10;

public class DebugDemo1 {

	public static void main(String[] args) {
		int total = 0;
		for (int i = 1; i <= 10; i++) {
			total += i;
		}
		System.out.println(total);
	}

}
