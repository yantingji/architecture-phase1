package com.itedu.lesson08;

public class ArrayDemo3 {

	public static void main(String[] args) {
		int[][] nums=new int[2][3];
		int nums1[][]=new int[3][4];
		nums1[0][0]=0;
	}

}
