package com.itedu.lesson08;

public class ArrayDemo2 {

	public static void main(String[] args) {
		String[] names = { "Jack", "Tom", "Rose" };
		String name = "Tom1";

		boolean b = false;
		for (String s : names) {
			if (s.equals(name)) {
				b = true;
				break;
				// System.out.println("存在");
			}
		}
		if (b) {
			System.out.println("存在");
		}else{
			System.out.println("不存�?");
		}

	}

}
