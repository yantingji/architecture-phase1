package com.itedu.lesson08;

public class ArrayDemo {

	public static void main(String[] args) {
		int age1, age2, age3, age4, age5;

		// ages = new int[5];
		

		// 赋�??
		// ages[0]=20;
		// ages[2]=30;

		// ages=new int[]{20,25,30,35,40,45};
		int[] ages = { 20, 30, 40 };
		

		int[] scores = new int[10];//默认初始值是0
		scores[2]=10;
		scores[5]=20;
		float[] scores1 = new float[10];//默认初始值是0.0
		boolean[] scores2 = new boolean[10];//默认初始值是false
		System.out.println(scores2[0]);
		
		String names[] = new String[5];
		System.out.println(names[0]);//默认初始值是null
		System.out.println("-------------------------------");
		for(int i=0;i<scores.length;i++){
			System.out.println(scores[i]);
		}
		//System.out.println(scores[10]);//不可越界
		System.out.println("-------------------------------");
		for(int score : scores){
			System.out.println(score);
		}
	}
}
