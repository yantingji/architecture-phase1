package com.itedu.lesson08;

/**
 * 求出�?组元素的�?大�?�与�?小�??
 * 
 * @author tanlan
 *
 */
public class ArrayDemo1 {

	public static void main(String[] args) {
		int[] nums = { 2, 5, 8, 3, 6, 8, 7 };

		// 求最大�??
		int max = nums[0],min=nums[0];
		for (int i = 1; i < nums.length; i++) {
			if (nums[i] > max) {
				max = nums[i];
			}
			if (nums[i] < min) {
				min = nums[i];
			}
		}
		System.out.println("�?大�?�：" + max);
		System.out.println("�?小�?�：" + min);
	}

}
