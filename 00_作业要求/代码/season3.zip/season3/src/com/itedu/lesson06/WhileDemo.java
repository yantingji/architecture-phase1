package com.itedu.lesson06;

public class WhileDemo {

	public static void main(String[] args) {
		int i = 200;
		while (i <= 100) {
			//if (i % 2 == 0) {
				System.out.println(i);
			//}
			i += 2;
		}

		// for (int j = 1; j <= 100; j++) {
		// System.out.println(j);
		// }
	}

}
