package com.itedu.lesson06;

public class DoWhileDemo {

	public static void main(String[] args) {
		int i = 150;
		do {
			if(i%3==0){
				System.out.println(i);
			}
			i++;
		} while (i <= 100);
	}

}
