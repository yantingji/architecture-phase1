package com.itedu.lesson06;

public class BreakDemo {

	int num = 10;

	public static void main(String[] args) {
		int i = 0;
		while (true) {
			System.out.println(++i);
			// i++;
			if (i == 100) {
				break;
			}
			System.out.println("hello");
		}
	}

}
