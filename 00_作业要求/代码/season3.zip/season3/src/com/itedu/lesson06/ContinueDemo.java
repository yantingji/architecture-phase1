package com.itedu.lesson06;

/**
 * 计算1-100之间的不�?5的�?�数的整数之�?
 * 
 * @author tanlan
 *
 */
public class ContinueDemo {

	public static void main(String[] args) {
		int total = 0;
		for (int i = 1; i <= 100; i++) {
			if (i % 5 == 0) {
				continue;// 终止本次循环，进入下�?次循�?
			}
			// if (i % 5 != 0){
			total += i;
			// }
		}
		System.out.println(total);
	}

}
