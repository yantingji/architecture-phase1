package com.itedu.lesson06;

import java.util.ArrayList;
import java.util.List;

public class ForDemo {

	public static void main(String[] args) {
		// for (int i = 1; i <= 100; i++) {
		// System.out.println(i);
		// }

		// 计算1-100之间整数之和
		int total = 0;
		for (int i = 1; i <= 100; i++) {
			total += i;
		}
		System.out.println(total);

		// 输出1-100之间的偶�?
		for (int i = 1; i <= 100; i++) {
			if (i % 2 == 0) {
				System.out.println(i);
			}
		}

		for (int i = 2; i <= 100; i += 2) {
			System.out.println(i);
		}
		
		List<String> list = new ArrayList<>();
		list.forEach(null);
	}

}
