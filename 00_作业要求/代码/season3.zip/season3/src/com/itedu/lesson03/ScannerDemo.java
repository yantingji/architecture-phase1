package com.itedu.lesson03;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		System.out.print("请输入一个整数：");
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		System.out.println(num);
	}

}
