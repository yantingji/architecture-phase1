package com.itedu.lesson03;

import java.math.BigDecimal;

public class DataTypeDemo {

	public static void main(String[] args) {
//		int num1=1000;
//		//int num2=3000000000;
//		int num2=0237;
//		int num3=-0765;
//		
//		int num4=0xff23d;
//		int num5=0XF99;
//		
//		int num6=0b11;
//		int num7=0B1;
//		
//		long num8=300L;
//		
//		
//		byte num9=127;
//		int num10=9999;
//;
//		
//		char c1='a';
//		char c2='1';
//		
//		char c4='\'';
//		System.out.print(c4);
//	
//		boolean b1=true;
//		boolean b2=false;
//		
//		float f1=12.345f;
//		float f2=34.98F;
//		BigDecimal bigDecimal = new BigDecimal(1);
//		
//		float f3=3E3F;
//		System.out.print(f3);
//		float f4=-42E-3f;
//		
//		//float f3=12.34;缂栬瘧閿�?
//		
//		double d1=12.34;
//		double d2=-23.45D;
//		
//		int num11=123_456;
//		double num12=0.123_456_789;
//		
//		int num13=0x12;
//		long num14=123L;
//		int num15=0_123;
//		
//		float f5=1.2f;
		
		long num16=100L;
		Long long1 =  new Long(num16);
		System.out.println(long1);
//		double num17=100;
//		
//		int num18=(int)1.2;
//		System.out.println();
//		System.out.println(num18);
		
	}

}
