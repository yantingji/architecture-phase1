package com.itedu.lesson07;

import java.util.Scanner;

public class StringDemo {

	public static void main(String[] args) {
		String s1 = "hello";
		// char c='a';

		String s2 = new String("hello");
		String s3;
		s3 = "Hello";

		String s4 = s1 + s2 + 10.12;
		System.out.println("结果是：" + 100);

		int length = s4.length();// 长度
		System.out.println(length);

		boolean b = s1.equalsIgnoreCase(s2);// 不区分大小写
		System.out.println(b);

		System.out.println(s1.toUpperCase());
		System.out.println(s2.toLowerCase());

		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));// 比较两个String是否相等，一定使用equals

		Scanner scanner = new Scanner(System.in);

		String s5 = scanner.next();
		System.out.println("您输入的�?:" + s5);
	}

}
