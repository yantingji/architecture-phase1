package com.itedu.lesson02;

public class VarDemo {

	public static void main(String[] args) {
		int money;
		money= 1500;
		
		// 在控制台输出1000
		System.out.println(money);
		
		int num=10;
		int _num=20;
		int $数字=30;
		System.out.print($数字);
		
		int try1=40;
	}

}
